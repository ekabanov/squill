package squill.mgen;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import squill.mgen.ClassInspectionUtil.ClassInfo;
import squill.mgen.naming.Conventions;
import squill.mgen.naming.NamingStrategy;

public class MapTable {

	private final DbTable table;
  private Map<String, MapColumn> mapColumns;
  private NamingStrategy namingStrategy;
  private ClassInfo modelClass;
  private List<MapForeignKey> foreignKeys = new ArrayList<MapForeignKey>();
 

  public MapTable(DbTable table, NamingStrategy namingStrategy, ClassInfo modelClass) {    
		this.table = table;
		this.namingStrategy = namingStrategy;
		this.modelClass = modelClass;		
		
		if (table.getForeignKeys() != null) {
		  //Determine unique keys
		  Set targetTablesOnce = new HashSet();
		  Set targetTablesMany = new HashSet();
		  
      for (DbForeignKey fk : table.getForeignKeys()) {
        if (targetTablesOnce.contains(fk.getRefTableName()))
          targetTablesMany.add(fk.getRefTableName());
        
        if (!targetTablesMany.contains(fk.getRefTableName()))
          targetTablesOnce.add(fk.getRefTableName());
        else 
          targetTablesOnce.remove(fk.getRefTableName());
      }
		  
		  for (DbForeignKey fk : table.getForeignKeys()) {
		    foreignKeys.add(new MapForeignKey(namingStrategy, table, fk, targetTablesOnce.contains(fk.getRefTableName())));
		  }
		}
	}

  
	public String getJavaName() {
	  return Conventions.javaBeanName(namingStrategy, table.getName());
	}

	/** @return Name of reference object */
	public String getRefName() {
		return Conventions.javaTableName(namingStrategy, table.getName());
	}
	
	public boolean hasModelClass() {
		return modelClass != null;
	}
	
	public String getModelClassName() {
		return modelClass.getName();
	}

  public boolean isReadOnly() {
    return table.isReadOnly();
  }
  public String getName() {
    return table.getName();
  }

  public String getTableName() {
    return getName().toLowerCase();
  }
  
  public boolean hasPrimaryKey() {
    return table.getPrimaryKeyColnames().size() == 1;
  }
  
  public MapColumn getPrimaryKey() {
    return mapColumns.get(table.getPrimaryKeyColnames().iterator().next());
  }
  
  public List<MapColumn> getNonPrimaryColumns() {
    List<MapColumn> result = new ArrayList<MapColumn>();
    
    for (MapColumn mapColumn : getColumns().values()) {
      if (hasPrimaryKey() && getPrimaryKey() != mapColumn)
        result.add(mapColumn);
    }
    
    return result;
  }
  
  public List<MapForeignKey> getForeignKeys() {
    return foreignKeys;
  }
  
  public Map<String, MapColumn> getColumns() {
    try {
      if (mapColumns!=null) return mapColumns;
      mapColumns = createMapColumns();
      return mapColumns;
    } catch (Exception e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }
  }

  private Map<String, MapColumn> createMapColumns() {
    final Collection<DbColumn> tableColumns = table.getColumns();
    Map<String, MapColumn> columns = new HashMap<String, MapColumn>();
    for (DbColumn tableColumn : tableColumns) {
      columns.put(tableColumn.getName(), new MapColumn(tableColumn,namingStrategy,modelClass));
    }
    return columns;
  }
}
