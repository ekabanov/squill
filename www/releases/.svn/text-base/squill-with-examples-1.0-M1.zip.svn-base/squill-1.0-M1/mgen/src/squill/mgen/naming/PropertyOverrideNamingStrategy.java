package squill.mgen.naming;

import java.util.Properties;

import squill.util.StringUtil;



public class PropertyOverrideNamingStrategy implements NamingStrategy {
  private final NamingStrategy result;
  private final Properties dbToJavaProps;

  public PropertyOverrideNamingStrategy(NamingStrategy result, Properties dbToJavaProps) {
        this.result = result;
        this.dbToJavaProps = dbToJavaProps;
  }

  public String getColumnName(String dbTableName, String dbColumnName) {
    String dbFullColumnName = key(dbTableName, dbColumnName);
    if (dbToJavaProps.containsKey(dbFullColumnName))
      return dbToJavaProps.getProperty(dbFullColumnName);
    
    return result.getColumnName(dbTableName, dbColumnName);
  }

  private String key(final String dbTableName, final String dbColumnName) {
    return dbTableName.concat(".").concat(dbColumnName);
  }

  public String getTypeName(String dbTableName) {
    if (dbToJavaProps.containsKey(dbTableName))
      return dbToJavaProps.getProperty(dbTableName);
    
    return result.getTypeName(dbTableName);
  }
}
