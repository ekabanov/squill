package squill.mgen;

/**
 * @author Michael Hunger
 * @since 27.08.2008
 */
public interface MessageLogger {
  void info(String message);
  void warning(String message);
  void error(String message, Throwable t);
}
