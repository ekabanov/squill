package squill.mgen.naming;

import squill.util.StringUtil;

/**
 * Type names are converted into lowercase and
 * names of database tables and columns are held out in upper case.
 *
 * @author Juhan Aasaru
 * @since 31.08.2008
 */
public class LowerCaseNaming implements NamingStrategy {
  public String getTypeName(String dbTableName) {
    return dbTableName.toLowerCase();
  }

  public String getColumnName(String dbTableName, String dbColumnName) {
    return dbColumnName.toLowerCase();
  }
}