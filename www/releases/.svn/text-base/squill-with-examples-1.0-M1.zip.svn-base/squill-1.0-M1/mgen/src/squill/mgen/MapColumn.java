package squill.mgen;

import static java.lang.String.format;


import org.objectweb.asm.Type;

import squill.mgen.ClassInspectionUtil.ClassInfo;
import squill.mgen.naming.NamingStrategy;
import squill.util.StringUtil;

public class MapColumn {

  private final DbColumn col;
  private final NamingStrategy namingStrategy;
  private boolean hasProperty = false;

  public MapColumn(DbColumn col, NamingStrategy namingStrategy, ClassInfo modelClass) {
    this.col = col;
    this.namingStrategy = namingStrategy;

    if (modelClass != null) {
      Class type = TypeMap.getType(col);
      boolean hasGetter = modelClass.getMethods().keySet().contains(
          "get" + getPropertyName() 
          + Type.getMethodDescriptor(
              Type.getType(type), new Type[] {}));
      
      boolean hasSetter = modelClass.getMethods().keySet().contains(
          "set" + getPropertyName() 
          + Type.getMethodDescriptor(
              Type.VOID_TYPE, new Type[] {Type.getType(type)}));      

      hasProperty = hasGetter && hasSetter;
      
      if (!hasProperty && (hasGetter || hasSetter)) {
        System.err.println(
            "The model class '" 
            + modelClass.getName() 
            + "' does defines only a getter or a setter for the property '" 
            + getPropertyName() + "'.");
      }
    }
  }

  public String getName() {
    return col.getName();
  }

  public String getJavaName() {
    return namingStrategy.getColumnName(col.getTable().getName(), col.getName());
  }
  
  public String getPropertyName() {
    return StringUtil.capitalize(getJavaName());
  }

  public String getJavaType() {
    return TypeMap.getTypeString(col);
  }

  public boolean isHasProperty() {
    return hasProperty;
  }

  public String genGetterSetter() {
    final String propertyName = getPropertyName();
    final String variableName = getJavaName();
    final String variableType = getJavaType();

    StringBuilder sb = new StringBuilder(200);

    sb.append(format("  public %s get%s() { return %s;}%n",variableType,propertyName,variableName));
    sb.append(format("  public void set%s(%s %3$s) { this.%3$s = %3$s; }%n%n",propertyName,variableType,variableName));

    return sb.toString();
  }



}
