package squill.mgen;

import static java.lang.String.format;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;


import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.types.resources.FileResource;

import squill.mgen.ClassInspectionUtil.ClassInfo;
import squill.mgen.naming.CamelCaseNaming;
import squill.mgen.naming.NamingStrategy;
import squill.mgen.naming.PropertyOverrideNamingStrategy;
import squill.util.FileUtil;

public class SquillMappingsTask extends Task implements MessageLogger {

  private static final String NAMING_STRATEGY_LOOKUP_PACKAGE = "squill.mgen.naming.";

  /**
   * Database JDBC URL.
   */
  private String url;

  /**
   * Database driver.
   */
  private String driver;

  /**
   * Database user name.
   */
  private String user;

  /**
   * Database password
   */
  private String password;

  /**
   * Database schema
   */
  private String schema;

  /**
   * Package name for model objects
   */
  private String packageName;

  /**
   * Path to directory where to output files into
   */
  private String outputPath;

  private String templateFile;

  private String namingStrategy;

  private File namingOverride;

  private Map<String, File> modelClassFiles = new HashMap<String, File>();

  public static URL[] classpathURLs;
  private static final String DEFAULT_STRATEGY_CLASS = CamelCaseNaming.class.getName();

  public void addConfiguredFileSet(FileSet fs) {
    for (Iterator i = fs.iterator(); i.hasNext();) {
      File file = ((FileResource) i.next()).getFile();
      if (file.getName().endsWith(".class"))
        modelClassFiles.put(file.getName().substring(0, file.getName().length() - 6), file);
    }
  }

  public static void main(String[] args) {
    SquillMappingsTask task = new SquillMappingsTask();
    task.setDriver("org.hsqldb.jdbcDriver");
    task.setUrl("jdbc:hsqldb:hsql://localhost/squilldemodb");
    task.setSchema("PUBLIC");
    task.setUser("SA");
    task.setPackageName("simple.data");
    task.setOutputPath("src");
    task.perform();
  }

  @Override
  public void execute() throws BuildException {
    info("Starting to generate TypeSafeSQL mappings out of database");


    try {
      long time = trace(null, 0L);
      DatabaseInfoReader databaseInfoReader = new DatabaseInfoReader(driver, url, user, password, schema, this);
      Collection<DbTable> tables = databaseInfoReader.gatherDatabaseInfo();
      time = trace("gather db info", time);
      generateMappings(tables, loadNamingStrategy());
      trace("generate mappings", time);
    }
    catch (Exception e) {
      throw new BuildException("Errror creating mapping files..." + e, e);
    }

    info("Finished generating");
  }

  private long trace(final String msg, final long time) {
    if (msg != null && time != 0L) {
      final long delta = System.nanoTime() - time;
      log(format("%s took %.2f ms.", msg, (double) delta / (1000 * 1000)), Project.MSG_INFO);
    }
    return System.nanoTime();
  }

  /**
   * @return Class that provides conversion between database names and type names
   */
  @SuppressWarnings({"unchecked"})
  private NamingStrategy loadNamingStrategy() {
    String strategyClassName = getStrategyClassName();
    return strategyInstance(strategyClassName);
  }

  private NamingStrategy strategyInstance(final String strategyClassName) {
    try {
      final Class<? extends NamingStrategy> strategyClass = (Class<? extends NamingStrategy>) Class.forName(strategyClassName);
      return addOverrides(strategyClass.newInstance());
    } catch (Exception e) {
      throw new BuildException(format("Problem loading naming strategy '%s' from class '%s'.", getNamingStrategy(), strategyClassName), e);
    }
  }

  private String getStrategyClassName() {
    final String strategyName = getNamingStrategy();
    String strategyClassName = DEFAULT_STRATEGY_CLASS;
    if (strategyName != null && strategyName.trim().length() > 0) {
      strategyClassName = strategyName.contains(".") ? strategyName : NAMING_STRATEGY_LOOKUP_PACKAGE + strategyName;
    }
    return strategyClassName;
  }

  private NamingStrategy addOverrides(NamingStrategy strategy) {
    if (getNamingOverride() == null) {
      return strategy;
    }
    try {
      Properties namingOverrideProperties = new Properties();
      namingOverrideProperties.load(new FileInputStream(getNamingOverride()));
      return new PropertyOverrideNamingStrategy(strategy, namingOverrideProperties);
    } catch (IOException e) {
      throw new RuntimeException("Could not load naming override properties from '" + getNamingOverride() + "'", e);
    }
  }

  /**
   * Generate mapping files based on the database information
   *
   * @param dbTableList List of database tables/views
   */
  public void generateMappings(Collection<DbTable> dbTableList, NamingStrategy namingStrategy) {
    info("Using naming strategy: " + namingStrategy.getClass());
    TableCodeGenerator codeGenerator = new VelocityTableCodeGenerator(getTemplateFile());
    final String packageName = getPackageName();
    for (DbTable curTable : dbTableList) {

      info("Processing table: " + curTable.getName());

      long time = trace("generate java code", 0L);

      ClassInfo modelClass = null;

      if (modelClassFiles.containsKey(namingStrategy.getTypeName(curTable.getName()))) {
        modelClass = ClassInspectionUtil.inspectClass(
            modelClassFiles.get(namingStrategy.getTypeName(curTable.getName())));
      }

      MapTable mapTable = new MapTable(curTable, namingStrategy, modelClass); // Mappings container

      String tableJavaCode = codeGenerator.generateJavaTableCode(packageName, mapTable);
      time = trace("generate java code", time);
      FileUtil.writeFile(tableJavaCode,FileUtil.javaFile(getOutputPath(), getPackageName(), mapTable.getJavaName()));
      trace("write file", time);
    }
  }

  public String getTemplateFile() {
    if (templateFile != null) return templateFile;
    return FileUtil.path(getClass()) + "Model";
  }

  public void setTemplateFile(final String templateFile) {
    this.templateFile = templateFile;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setSchema(String schema) {
    this.schema = schema;
  }

  public void setPackageName(String packageName) {
    this.packageName = packageName;
  }

  public void setOutputPath(String outputPath) {
    this.outputPath = outputPath;
  }

  public String getOutputPath() {
    String lastChar = outputPath.substring(outputPath.length() - 1, outputPath.length());

    if ("${output.path}".equalsIgnoreCase(outputPath)) {
      return "output/";
    } else if ("/".equals(lastChar) || "\\".equals(lastChar)) {
      return outputPath;
    }
    return outputPath + "/";

  }

  public String getPackageName() {
    if ("${java.package}".equals(packageName)
        || (this.packageName != null && this.packageName.trim().length() == 0)) {
      return null;
    } else {
      return packageName;
    }
  }

  public void warning(String message) {
    log(message, Project.MSG_WARN);
  }

  public void info(String message) {
    log(message, Project.MSG_INFO);
  }

  public void error(String message, Throwable t) {
    log(message, t, Project.MSG_ERR);
  }

  public String getNamingStrategy() {
    return namingStrategy;
  }

  public void setNamingStrategy(String namingStrategy) {
    this.namingStrategy = namingStrategy;
  }

  public File getNamingOverride() {
    return namingOverride;
  }

  public void setNamingOverride(File namingOverride) {
    this.namingOverride = namingOverride;
  }
}
