package squill.mgen.naming;

import squill.util.StringUtil;

/**
 * Naming strategy where Java type names are in singular,
 * but database table names are in plural.
 * 
 * Words are separated using CamelCase in Java and underscores in database.
 * TODO inetegrate Inflector library https://inflector.dev.java.net/ 
 * @author Juhan Aasaru
 * @since 31.08.2008
 */
public class PluralCamelCaseNaming implements NamingStrategy {
  private CamelCaseNaming delegate = new CamelCaseNaming();
  
  private static String[] pluralSuffixes = new String[] {"ies", "s"};
  private static String[] singleSuffixes = new String[] {"y", ""};

  public String getTypeName(String dbTableName) {    
    // TODO add rules for exceptions (Mice -> Mouse) etc
    
    for (int i = 0; i < pluralSuffixes.length; i++) {
      if (dbTableName.toLowerCase().endsWith(pluralSuffixes[i])) {
        dbTableName = 
          dbTableName.substring(0, dbTableName.length() 
              - pluralSuffixes[i].length()) 
              + singleSuffixes[i];
        break;
      }
    }
    
    return delegate.getTypeName(dbTableName);
  }

  public String getColumnName(String dbTableName, String dbColumnName) {
    return delegate.getColumnName(dbTableName, dbColumnName);
  }
}
