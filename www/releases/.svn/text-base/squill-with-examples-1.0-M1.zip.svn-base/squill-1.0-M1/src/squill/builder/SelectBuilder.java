/**
 *
 */
package squill.builder;

import static squill.functions.Operations.and;
import squill.db.Database;
import squill.query.QueryContext;
import squill.query.from.FromExpression;
import squill.query.select.ReadableTable;
import squill.query.where.WhereExpression;


/**
 * This transfer is output by from() method.
 * NB! Extending WhereBuilder has point here
 */
public class SelectBuilder extends SelWhereBuilder {


  public SelectBuilder(QueryContext ctx, Database database, ReadableTable baseTable, FromExpression... fromExprs) {
    super(ctx, database);
    addTable(baseTable);
    addTables(fromExprs);
  }

  public SelWhereBuilder where(WhereExpression whereClause) {
        wherePart.addWhereClause(whereClause);
        return this;
    }

    /**
     * Placeholder for where() clause, does not add any restrictions
     */
    public SelWhereBuilder where() {
        return this;
    }

    /**
     * Takes comma separated array of restrictions and combines them with AND operator
     */
    public SelWhereBuilder where(WhereExpression... whereClauses) {
      if (whereClauses==null || whereClauses.length==0) return this; 
      // By default - having multiple WHERE clauses means that they are combined with AND
      return where(and(whereClauses));
    }


}
