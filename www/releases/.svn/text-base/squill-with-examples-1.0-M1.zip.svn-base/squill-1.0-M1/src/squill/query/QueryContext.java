package squill.query;

public interface QueryContext {
  String uniqueAlias(String prefix);
}
