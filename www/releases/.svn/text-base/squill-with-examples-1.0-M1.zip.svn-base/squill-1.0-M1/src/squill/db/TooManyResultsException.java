package squill.db;

public class TooManyResultsException extends TypedSQLException {
	private static final long serialVersionUID = 1L;

	public TooManyResultsException() {
		super("Too many results! Expected to get at most one result. Change the WHERE clause!");
	}
}
