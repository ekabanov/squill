package squill.query.cud;

import static java.lang.String.format;

import java.util.List;
import java.util.Map;

import squill.query.select.Column;
import squill.query.select.ReadableTable;




public class UpdateCruElement<OBJ> extends AbstractCUDElement<OBJ> implements UpdateElement<OBJ> {


    public UpdateCruElement(ReadableTable<OBJ> table, OBJ updateObj) {
        super(table, updateObj);
    }


    protected String createSqlAndArgs(Map<Column, Object> columnValueMap, List<Object> argsList) {
        StringBuilder updateSql = new StringBuilder();
        for (Column column : columnValueMap.keySet()) {
            updateSql.append(format(", %s = ?", column.getColumnNameWithTableSql()));
            argsList.add(columnValueMap.get(column));
        }

        return updateSql.substring(2);
    }
}
