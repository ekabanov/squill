package squill.query;

import squill.alias.AliasResolver;

public class QueryContextImpl implements QueryContext {
  private AliasResolver ar = new AliasResolver();
  
  public String uniqueAlias(String prefix) {
    return ar.uniqueAlias(prefix);
  }
}
