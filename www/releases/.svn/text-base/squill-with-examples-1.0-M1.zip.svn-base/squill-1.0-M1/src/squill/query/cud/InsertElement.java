package squill.query.cud;

/**
 * @author Michael Hunger
 * @since 24.08.2008
 */
public interface InsertElement extends CUDElement {
}
