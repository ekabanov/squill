/**
 *
 */
package squill.query.select;

import static java.lang.String.format;
import squill.alias.Alias;
import squill.util.StringUtil;
import squill.util.ToString;

/**
 * All fields extend this class.
 *
 * @param <FIELD> Field type
 */
public class Column<FIELD, TABLE> extends BaseSelectExpression<FIELD> {
  private final ReadableTable<TABLE> table;
  private final String columnName;

  private final Alias fieldAlias;
  private final String modelSetterName;
  private final String modelGetterName;
  private final String propertyName;
  
  private final Class<FIELD> resultType;
  private FIELD value;  
  
  public static final ToString<Column> GET_COLUMN_NAME = new ToString<Column>() {
    public String toString(Column column) {
      return column.getColumnName();
    }
  };
  public static final ToString<Column> GET_NAME = new ToString<Column>() {
    public String toString(Column column) {
      return column.getColumnNameWithTableSql();
    }
  };
  public static final ToString<Column> GET_SQL_STRING = new ToString<Column>() {
    public String toString(final Column column) {
      return column.getDefaultSql();
    }
  };
  
  public Column(String columnName, Class<FIELD> resultType, String propertyName, ReadableTable<TABLE> table) {
    this.fieldAlias = Alias.newColumnAlias();
    this.columnName = columnName;
    this.resultType = resultType;
    this.propertyName = propertyName;
    this.table = table;
    final String capitalizedPropertyName = StringUtil.capitalize(propertyName);
    this.modelSetterName="set"+ capitalizedPropertyName;
    this.modelGetterName="get"+ capitalizedPropertyName;
  }

  @Override
  public String getDefaultSql() {
    return getColumnNameWithTableSql();
  }

  public String getColumnAsAliasSql() {
    return format("%s AS %s", getDefaultSql(), getAlias());
  }
  
  public Class<FIELD> getTableType() {
    return resultType;
  }

  public String getColumnName() {
    return columnName;
  }

  public String getColumnNameWithTableSql() {
    return format("%s.%s", table.getAlias(), columnName);
  }

  public String getAlias() {
    return table.getAlias() + fieldAlias.resolve(getContext());
  }

  // get the field name of model object
  // this can be set by constructor or lazily found out on first call
  public String getModelSetterName() {
    return modelSetterName;
  }
  
  String getModelGetterName() {
    return modelGetterName;
  }

  public ReadableTable<TABLE> getTable() {
    return table;
  }
  public void set(FIELD value) { this.value = value; }
  public FIELD get() { return this.value; } 
}
