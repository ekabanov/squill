package squill.tuple;

public interface Tuple {

}
