package squill.query.cud;

import squill.query.QueryPart;

/**
 * @author Michael Hunger
 * @since 24.08.2008
 */
public interface CUDElement extends QueryPart {
}
