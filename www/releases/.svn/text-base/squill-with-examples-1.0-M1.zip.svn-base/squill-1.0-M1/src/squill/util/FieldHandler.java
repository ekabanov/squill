package squill.util;

import java.lang.reflect.Field;

/**
 * @author Michael Hunger
 * @since 24.08.2008
 */
public interface FieldHandler {
    boolean handleField(Field field) throws Exception;
}
