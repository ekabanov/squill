package squill.tuple;

import squill.tuple.Tuple;

public class   Tuple10 < T1,T2,T3,T4,T5,T6,T7,T8,T9,T10 >  implements Tuple {
    public final T1 v1;
    public final T2 v2;
    public final T3 v3;
    public final T4 v4;
    public final T5 v5;
    public final T6 v6;
    public final T7 v7;
    public final T8 v8;
    public final T9 v9;
    public final T10 v10;
    public  Tuple10 (  T1 v1, T2 v2, T3 v3, T4 v4, T5 v5, T6 v6, T7 v7, T8 v8, T9 v9, T10 v10 ) {
      this.v1 = v1;
      this.v2 = v2;
      this.v3 = v3;
      this.v4 = v4;
      this.v5 = v5;
      this.v6 = v6;
      this.v7 = v7;
      this.v8 = v8;
      this.v9 = v9;
      this.v10 = v10;
    }

  public static < P1,P2,P3,P4,P5,P6,P7,P8,P9,P10 > Tuple10< P1,P2,P3,P4,P5,P6,P7,P8,P9,P10 > _( P1 v1,P2 v2,P3 v3,P4 v4,P5 v5,P6 v6,P7 v7,P8 v8,P9 v9,P10 v10 ) {
    return new Tuple10< P1,P2,P3,P4,P5,P6,P7,P8,P9,P10 >( v1,v2,v3,v4,v5,v6,v7,v8,v9,v10 );
  }

  @Override
  public String toString() {
    return "(" +  v1 +","+ v2 +","+ v3 +","+ v4 +","+ v5 +","+ v6 +","+ v7 +","+ v8 +","+ v9 +","+ v10  + ")";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Tuple10 tuple = (Tuple10) o;
        if (v1 == null ? tuple.v1 != null : !v1.equals(tuple.v1)) return false;
        if (v2 == null ? tuple.v2 != null : !v2.equals(tuple.v2)) return false;
        if (v3 == null ? tuple.v3 != null : !v3.equals(tuple.v3)) return false;
        if (v4 == null ? tuple.v4 != null : !v4.equals(tuple.v4)) return false;
        if (v5 == null ? tuple.v5 != null : !v5.equals(tuple.v5)) return false;
        if (v6 == null ? tuple.v6 != null : !v6.equals(tuple.v6)) return false;
        if (v7 == null ? tuple.v7 != null : !v7.equals(tuple.v7)) return false;
        if (v8 == null ? tuple.v8 != null : !v8.equals(tuple.v8)) return false;
        if (v9 == null ? tuple.v9 != null : !v9.equals(tuple.v9)) return false;
        if (v10 == null ? tuple.v10 != null : !v10.equals(tuple.v10)) return false;
        return true;
  }

  @Override
  public int hashCode() {
    int result = 0;
        result = 31 * result + (v1 != null ? v1.hashCode() : 0);
        result = 31 * result + (v2 != null ? v2.hashCode() : 0);
        result = 31 * result + (v3 != null ? v3.hashCode() : 0);
        result = 31 * result + (v4 != null ? v4.hashCode() : 0);
        result = 31 * result + (v5 != null ? v5.hashCode() : 0);
        result = 31 * result + (v6 != null ? v6.hashCode() : 0);
        result = 31 * result + (v7 != null ? v7.hashCode() : 0);
        result = 31 * result + (v8 != null ? v8.hashCode() : 0);
        result = 31 * result + (v9 != null ? v9.hashCode() : 0);
        result = 31 * result + (v10 != null ? v10.hashCode() : 0);
        return result;
  }
}