package squill.format;

import squill.query.QueryPart;

public interface SqlFormat {
  String format(QueryPart queryPart);
}
