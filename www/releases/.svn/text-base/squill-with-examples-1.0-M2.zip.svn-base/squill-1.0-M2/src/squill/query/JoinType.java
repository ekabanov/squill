package squill.query;

public enum JoinType {
	LEFT, RIGHT, INNER, OUTER
}
