package squill.query.from;



/**
 * Interface for types that go between .from() during select.
 * These are tables and joins.
 */
public interface FromExpression {
  boolean isJoin();
  String getFromSql();
}
