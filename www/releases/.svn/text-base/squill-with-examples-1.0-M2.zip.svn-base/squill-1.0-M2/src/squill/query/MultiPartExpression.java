package squill.query;

import java.util.List;


public interface MultiPartExpression<T> extends Expression<T> {
  List<? extends Expression<?>> getParts();
  String getOperator();
}
