package squill.tuple;

import java.util.Arrays;

public interface Tuple {
}
