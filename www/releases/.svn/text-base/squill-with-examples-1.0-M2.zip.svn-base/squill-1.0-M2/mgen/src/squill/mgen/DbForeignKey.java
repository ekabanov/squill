package squill.mgen;

public class DbForeignKey {

	private String keyName; // name of foreign key (defaults to table name)
	private String colName; // name of local column
	
	private String refTableName; // referred table name
	private String refColName;   // referred column name
	
	
	public String getKeyName() {
		return keyName;
	}
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	public String getRefTableName() {
		return refTableName;
	}
	public void setRefTableName(String refTableName) {
		this.refTableName = refTableName;
	}
	public String getRefColName() {
		return refColName;
	}
	public void setRefColName(String refColName) {
		this.refColName = refColName;
	}	
}
